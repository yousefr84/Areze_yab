from django.contrib import admin
from .models import *

admin.site.register(Company)
admin.site.register(SalesAndMarketing)
admin.site.register(HumanResources)
admin.site.register(FinancialResources)
admin.site.register(CapitalStructure)
admin.site.register(CustomerRelationshipManagement)
admin.site.register(ManagementOrganizationalStructure)
admin.site.register(ManufacturingAndProduction)
admin.site.register(ProductCompetitiveness)
admin.site.register(ResearchAndDevelopment)




